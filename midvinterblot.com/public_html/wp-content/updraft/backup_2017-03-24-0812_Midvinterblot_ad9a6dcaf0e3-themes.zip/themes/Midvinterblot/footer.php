<?php
/**
 * Template for displaying the footer
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>


		</div>
		<a class="hidden" href="https://plus.google.com/u/0/b/109455481729744341165/109455481729744341165" >Google Plus</a>
	</div>
</div>
<!-- Contact Box -->
<script type="text/javascript" src="js/custom.js"></script>

<!-- Linktracking -->
<script type="text/javascript" src="<?php echo $res_folder; ?>js/tracklink.js"></script>


<?php wp_footer(); ?>

</body>
</html>